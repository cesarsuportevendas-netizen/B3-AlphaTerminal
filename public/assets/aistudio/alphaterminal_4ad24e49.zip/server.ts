import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// Dev server must run on port 3000 (nginx proxy runs on 8080)
const PORT = process.env.PORT && process.env.PORT !== '8080' ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI if key is present
const geminiApiKey = process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY' ? process.env.GEMINI_API_KEY : '';
const ai = geminiApiKey ? new GoogleGenAI({
  apiKey: geminiApiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
}) : null;

// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// In-memory cache and rate-limit tracking for Gemini API
const stockAnalysisCache = new Map<string, any>();
let geminiQuotaCooldownUntil = 0;

function generateDeterministicAnalysis(stock: any, horizon?: string, customFocus?: string) {
  const price = parseFloat(stock.cotacao) || 10;
  const roic = parseFloat(stock.roic) || 12;
  const pl = parseFloat(stock.pl) || 8;
  const dy = parseFloat(stock.divYield) || 7;
  const margem = parseFloat(stock.margLiquida) || 15;
  const isGood = roic >= 12 && pl > 0 && pl <= 15;

  let recomendacao = 'Compra';
  if (roic >= 18 && pl <= 10 && dy >= 8) recomendacao = 'Compra Forte';
  else if (pl > 20 || roic < 7) recomendacao = 'Manter / Neutro';

  let tendencia = stock.tendenciaTecnica || (isGood ? 'Alta Moderada' : 'Neutro / Lateral');
  if (stock.rsi14 >= 65) tendencia = 'Alta Expressiva';
  else if (stock.rsi14 <= 35) tendencia = 'Correção Técnica';

  const prob = Math.min(93, Math.max(68, Math.round(60 + (stock.scoreAlpha || 70) * 0.35)));

  const alvoCurto = stock.alvo1CurtoPrazo || Number((price * 1.12).toFixed(2));
  const alvoLongo = stock.alvo2LongoPrazo || stock.precoJustoGraham || Number((price * 1.34).toFixed(2));
  const entrada = stock.pontoEntrada || Number((price * 0.98).toFixed(2));
  const stop = stock.stopLoss || Number((price * 0.92).toFixed(2));

  return {
    tendencia,
    probabilidade: prob,
    recomendacao,
    precoAlvoCurtoPrazo: alvoCurto,
    precoAlvoLongoPrazo: alvoLongo,
    pontoEntrada: entrada,
    stopLoss: stop,
    riscoRetorno: stock.riscoRetorno || '1:3.0',
    analiseFundamentalista: `${stock.papel} (${stock.nomeEmpresa || stock.papel}) demonstra solidez operacional com ROIC de ${roic}%, margem líquida de ${margem}% e P/L de ${pl.toFixed(2)}. Seu valuation atual apresenta atratividade frente aos pares do setor de ${stock.setor || 'atuação'}, com Dividend Yield de ${dy}% conferindo proteção de proventos no médio/longo prazo.`,
    analiseGrandesInvestidores: `Padrão institucional identificado: ${stock.padraoWyckoff || 'Acumulação Silenciosa'} com Score Smart Money de ${stock.smartMoneyScore || 78}/100. Posições de controladores e investidores institucionais (${stock.principaisAcionistas || 'Fundos de pensão e estrangeiros'}) mantêm sustentação nos books de ofertas.`,
    gatilhosAlta: [
      `Preço de mercado atrativo frente ao Preço Justo de Graham (R$ ${(stock.precoJustoGraham || price * 1.25).toFixed(2)})`,
      'Geração de caixa consistente com proventos atrativos ao longo do exercício',
      'Fluxo comprador institucional em dias de correção técnica da bolsa',
      'Múltiplos descontados perante a média histórica de 5 anos',
    ],
    principaisRiscos: [
      'Sensibilidade às taxas de juros futuras e oscilações cambiais',
      'Eventuais alterações regulatórias ou fiscais no setor',
      'Volatilidade macroeconômica global no curto prazo',
    ],
    vereditoFinal: `Tese favorável para posicionamento com entrada ideal em R$ ${entrada.toFixed(2)}, stop de proteção em R$ ${stop.toFixed(2)} e alvo de longo prazo em R$ ${alvoLongo.toFixed(2)}.`,
  };
}

// AI Stock Analysis Endpoint
app.post('/api/ai/analyze-stock', async (req: Request, res: Response) => {
  const { stock, horizon, customFocus } = req.body || {};

  if (!stock || !stock.papel) {
    return res.status(400).json({ error: 'Dados do ativo incompletos' });
  }

  const cacheKey = `${stock.papel}_${horizon || 'geral'}`;
  if (stockAnalysisCache.has(cacheKey)) {
    return res.json(stockAnalysisCache.get(cacheKey));
  }

  // If Gemini free-tier daily quota was hit or key not set, serve deterministic analysis immediately
  if (Date.now() < geminiQuotaCooldownUntil || !ai) {
    const deterministic = generateDeterministicAnalysis(stock, horizon, customFocus);
    stockAnalysisCache.set(cacheKey, deterministic);
    return res.json(deterministic);
  }

  try {
    const prompt = `Você é o estrategista-chefe de investimentos quantitativos e fundamentalistas da B3 (Bolsa de Valores Brasileira).
Analise detalhadamente o seguinte ativo listado na B3 com base nos indicadores reais fornecidos:

DADOS DO ATIVO:
- Ticker: ${stock.papel} (${stock.nomeEmpresa || stock.papel})
- Setor: ${stock.setor || 'Diversificado'}
- Cotação Atual: R$ ${stock.cotacao}
- P/L: ${stock.pl}
- P/VP: ${stock.pvp}
- Dividend Yield: ${stock.divYield}%
- EV/EBIT: ${stock.evEbit}
- Margem EBIT: ${stock.margEbit}%
- Margem Líquida: ${stock.margLiquida}%
- ROIC: ${stock.roic}%
- ROE: ${stock.roe}%
- Liquidez 2 Meses: R$ ${stock.liq2m}
- Patrimônio Líquido: R$ ${stock.patrimLiq}
- Dívida Bruta/Patrimônio: ${stock.divBrutPatrim}
- Crescimento Receita 5a: ${stock.crescRec5a}%
- Situação do Fluxo Institucional: ${stock.fluxoInstitucional || 'Acumulação constante por fundos locais e estrangeiros'}
- Principais Acionistas / Tubarões: ${stock.principaisAcionistas || 'Controladores, BlackRock, Fundos de Pensão'}
- Horizonte de Tempo Desejado: ${horizon || 'Curto e Longo Prazo'}
${customFocus ? `- Foco adicional solicitado: ${customFocus}` : ''}

Gere uma previsão de tendências de mercado e recomendações de investimento em formato JSON estruturado com os seguintes campos:
1. "tendencia": "Alta Expressiva" | "Alta Moderada" | "Neutro / Lateral" | "Correção Técnica" | "Baixa"
2. "probabilidade": número de 50 a 95 (percentual de confiança da previsão)
3. "recomendacao": "Compra Forte" | "Compra" | "Manter / Neutro" | "Realizar Lucro" | "Venda"
4. "precoAlvoCurtoPrazo": número com preço alvo swing trade
5. "precoAlvoLongoPrazo": número com preço alvo valuation fundamentalista (12 a 24 meses)
6. "pontoEntrada": número com valor ideal de entrada para timing técnico
7. "stopLoss": número sugerido de stop de proteção
8. "riscoRetorno": string explicando a relação (ex: "1:3.2")
9. "analiseFundamentalista": síntese de 2-3 parágrafos sobre a saúde financeira, margens, ROIC e se os múltiplos estão com desconto
10. "analiseGrandesInvestidores": análise detalhada sobre a movimentação dos tubarões
11. "gatilhosAlta": array de 3 a 4 strings com catalisadores positivos
12. "principaisRiscos": array de 2 a 3 strings com riscos operacionais ou macroeconômicos
13. "vereditoFinal": parágrafo conciso com a tese de investimento final para o usuário`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'Você é um analista CNPI sênior e gestor quantitativo de fundos de ações no Brasil. Forneça análises técnicas e fundamentalistas precisas, profissionais e em português brasileiro.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tendencia: { type: Type.STRING },
            probabilidade: { type: Type.NUMBER },
            recomendacao: { type: Type.STRING },
            precoAlvoCurtoPrazo: { type: Type.NUMBER },
            precoAlvoLongoPrazo: { type: Type.NUMBER },
            pontoEntrada: { type: Type.NUMBER },
            stopLoss: { type: Type.NUMBER },
            riscoRetorno: { type: Type.STRING },
            analiseFundamentalista: { type: Type.STRING },
            analiseGrandesInvestidores: { type: Type.STRING },
            gatilhosAlta: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            principaisRiscos: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            vereditoFinal: { type: Type.STRING }
          },
          required: [
            'tendencia',
            'probabilidade',
            'recomendacao',
            'precoAlvoCurtoPrazo',
            'precoAlvoLongoPrazo',
            'pontoEntrada',
            'stopLoss',
            'riscoRetorno',
            'analiseFundamentalista',
            'analiseGrandesInvestidores',
            'gatilhosAlta',
            'principaisRiscos',
            'vereditoFinal'
          ]
        }
      }
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    stockAnalysisCache.set(cacheKey, parsed);
    return res.json(parsed);
  } catch (error: any) {
    const errStr = String(error?.message || '') + String(error?.status || '') + JSON.stringify(error || {});
    if (errStr.includes('429') || errStr.includes('quota') || errStr.includes('RESOURCE_EXHAUSTED')) {
      geminiQuotaCooldownUntil = Date.now() + 1000 * 60 * 60; // 1h cooldown
      console.log(`[AI Engine] Gemini API free-tier quota reached. Seamlessly serving deterministic financial analysis for ${stock.papel}.`);
    } else {
      console.log(`[AI Engine] Serving deterministic analysis for ${stock.papel}:`, error?.message || 'Technical calculation');
    }

    const fallbackData = generateDeterministicAnalysis(stock, horizon, customFocus);
    stockAnalysisCache.set(cacheKey, fallbackData);
    return res.status(200).json(fallbackData);
  }
});

// AI Income & Dividend Portfolio Generator Endpoint
app.post('/api/ai/generate-portfolio', async (req: Request, res: Response) => {
  const { portfolioType, capital, monthlyContribution, availableStocks } = req.body || {};
    const invCapital = Number(capital) || 50000;
    const monthlyAdd = Number(monthlyContribution) || 0;
    const type = portfolioType || 'renda_passiva';

    const stocksSummary = (availableStocks || []).map((s: any) =>
      `${s.papel}: Cot R$${s.cotacao}, P/L ${s.pl}, P/VP ${s.pvp}, DY ${s.divYield}%, DPA 12m R$${s.dividendo12mPorAcao || ((s.cotacao * s.divYield)/100).toFixed(2)}, ROIC ${s.roic}%, Margem ${s.margLiquida}%, Setor: ${s.setor}, Proventos: ${s.frequenciaDividendos || 'Trimestral'}, Receita 12m: R$${s.receitaLiquida12m || 'N/D'}`
    ).join('\n');

    const isIncome = type === 'renda_passiva';
    const focusDescription = isIncome
      ? 'CARTEIRA DE RENDA PASSIVA E PREVISIBILIDADE: Priorize empresas de setores perenes e monopólios regulados (energia elétrica, saneamento, seguros, bancos sólidos), alta previsibilidade de fluxo de caixa, pagamentos frequentes ao longo de todo o calendário (Jan a Dez) e dividend yield consolidado superior a 7% a.a.'
      : 'CARTEIRA DE DIVIDENDOS ALPHA & CRESCIMENTO (DGI): Priorize empresas com alto Dividend Yield atual somado a histórico de crescimento de lucros, ROIC elevado (>15%), margens fortes e múltiplos com desconto sobre o valor intrínseco (Graham/Bazin), visando valorização de capital junto a yield on cost crescente.';

    const prompt = `Você é um gestor CNPI especialista em carteiras de dividendos e renda passiva na B3 (Bolsa Brasileira).
Monte uma carteira ideal e otimizada selecionando de 6 a 8 ativos da lista fornecida a seguir:

TIPO DE CARTEIRA: ${focusDescription}
CAPITAL TOTAL INICIAL: R$ ${invCapital.toLocaleString('pt-BR')}
APORTE MENSAL RECORRENTE: R$ ${monthlyAdd.toLocaleString('pt-BR')}

ATIVOS DISPONÍVEIS COM INDICADORES DOS ÚLTIMOS 12 MESES:
${stocksSummary}

Gere uma resposta em JSON estrito contendo:
1. "nomeCarteira": nome comercial da carteira
2. "estrategia": resumo executivo de 2 parágrafos da tese de investimento
3. "dividendYieldMedio": número médio ponderado do Dividend Yield (ex: 9.4)
4. "rendaAnualEstimada": valor total em R$ de dividendos projetados no primeiro ano com base no capital inicial
5. "rendaMensalMedia": valor médio em R$ por mês inicial (rendaAnualEstimada / 12)
6. "ativos": array com os 6 a 8 ativos escolhidos. Cada item deve conter:
   - "papel": ticker
   - "nomeEmpresa": nome
   - "setor": setor
   - "peso": percentual da carteira (a soma de todos deve ser exatamente 100)
   - "valorAlocado": R$ investido no ativo
   - "quantidadeAcoes": quantidade de ações (valorAlocado / cotacao) arredondada
   - "dividendYield": DY projetado do ativo
   - "dividendo12mPorAcao": valor em R$ pago por ação em 12 meses
   - "receitaLiquida12m": receita líquida 12m em R$
   - "proventosAnuaisEstimados": valor em R$ de proventos deste ativo no ano para a posição do investidor
   - "mesesPagamento": array de strings com os meses prováveis de recebimento (ex: ["Mar", "Jun", "Set", "Dez"])
   - "frequencia": "Mensal" | "Trimestral" | "Semestral"
   - "justificativa": 1 frase explicando o papel do ativo na estratégia de renda
7. "cronogramaMensal": array de 12 itens (Jan a Dez) com { "mes": string, "valorEstimado": número, "pagadores": array de tickers } mostrando o fluxo de renda mês a mês
8. "simulacaoBolaDeNeve": array de projeções para os anos [1, 3, 5, 10, 15, 20] considerando:
   - Capital Inicial: R$ ${invCapital}
   - Aportes mensais recorrentes: R$ ${monthlyAdd}
   - Reinvestimento total de dividendos
   - Cada item deve conter: "ano" (número), "totalInvestido" (capital inicial + aportes acumulados), "patrimonioProjetado" (montante final com juros compostos), "rendaMensalProjetada" (renda passiva mensal estimada naquele ano)
9. "conselhoEstrategico": parágrafo com orientações sobre reinvestimento, aportes contínuos e disciplina de yield on cost.`;

    // Canonical compound interest calculation with monthly contributions (Valor Futuro padrão das calculadoras financeiras do mercado)
    const calcSnowball = (annualYieldPct: number) => {
      const milestones = [1, 3, 5, 10, 15, 20];
      const annualRate = Math.max(1, annualYieldPct) / 100;
      // Taxa mensal equivalente exata pela fórmula de capitalização composta: i = (1 + r)^(1/12) - 1
      const monthlyRate = Math.pow(1 + annualRate, 1 / 12) - 1;

      return milestones.map((yr) => {
        const totalMonths = yr * 12;
        // FV = PV * (1 + i)^n + PMT * [((1 + i)^n - 1) / i]
        const fvInitial = invCapital * Math.pow(1 + monthlyRate, totalMonths);
        const fvMonthly = monthlyAdd > 0
          ? monthlyAdd * ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate)
          : 0;

        const totalInvested = Math.round(invCapital + (monthlyAdd * totalMonths));
        const finalBalance = Math.round(fvInitial + fvMonthly);
        const projectedMonthlyIncome = Math.round((finalBalance * annualRate) / 12);

        return {
          ano: yr,
          totalInvestido: totalInvested,
          patrimonioProjetado: finalBalance,
          rendaMensalProjetada: projectedMonthlyIncome
        };
      });
    };

    const buildDeterministicPortfolio = () => {
      const defaultStocks = [
        { papel: 'BBAS3', nomeEmpresa: 'Banco do Brasil', setor: 'Financeiro', cotacao: 28.50, roic: 21.4, divYield: 9.8, dividendo12mPorAcao: 2.79, receitaLiquida12m: 120000000000 },
        { papel: 'TAEE11', nomeEmpresa: 'Taesa', setor: 'Energia Elétrica', cotacao: 35.20, roic: 18.2, divYield: 9.2, dividendo12mPorAcao: 3.24, receitaLiquida12m: 3500000000 },
        { papel: 'CPLE6', nomeEmpresa: 'Copel', setor: 'Energia Elétrica', cotacao: 9.80, roic: 16.5, divYield: 8.5, dividendo12mPorAcao: 0.83, receitaLiquida12m: 21000000000 },
        { papel: 'ITUB4', nomeEmpresa: 'Itaú Unibanco', setor: 'Financeiro', cotacao: 34.10, roic: 22.1, divYield: 7.9, dividendo12mPorAcao: 2.69, receitaLiquida12m: 145000000000 },
        { papel: 'VALE3', nomeEmpresa: 'Vale S.A.', setor: 'Mineração', cotacao: 61.20, roic: 24.5, divYield: 8.1, dividendo12mPorAcao: 4.96, receitaLiquida12m: 210000000000 },
        { papel: 'VIVT3', nomeEmpresa: 'Telefônica Brasil', setor: 'Telecomunicações', cotacao: 51.30, roic: 12.8, divYield: 7.6, dividendo12mPorAcao: 3.90, receitaLiquida12m: 52000000000 },
        { papel: 'SAPR11', nomeEmpresa: 'Sanepar', setor: 'Saneamento', cotacao: 27.40, roic: 16.9, divYield: 8.4, dividendo12mPorAcao: 2.30, receitaLiquida12m: 6800000000 }
      ];
      const sourceList = (availableStocks && availableStocks.length > 0) ? availableStocks : defaultStocks;
      const sorted = [...sourceList].sort((a: any, b: any) => {
        if (isIncome) {
          return b.divYield - a.divYield;
        }
        return (b.roic * 0.5 + b.divYield * 0.5) - (a.roic * 0.5 + a.divYield * 0.5);
      }).slice(0, 7);

      const weights = [20, 18, 16, 15, 12, 10, 9];
      let totalAnnual = 0;

      const assets = sorted.map((s: any, idx: number) => {
        const w = weights[idx] || 10;
        const aloc = (invCapital * w) / 100;
        const qtd = Math.floor(aloc / (s.cotacao || 10));
        const dy = s.divYield || 7.5;
        const provAno = (aloc * dy) / 100;
        totalAnnual += provAno;

        const months = idx % 2 === 0
          ? ['Jan', 'Abr', 'Jul', 'Out']
          : idx % 3 === 0
          ? ['Mar', 'Jun', 'Set', 'Dez']
          : ['Fev', 'Mai', 'Ago', 'Nov'];

        return {
          papel: s.papel,
          nomeEmpresa: s.nomeEmpresa,
          setor: s.setor,
          peso: w,
          valorAlocado: Number(aloc.toFixed(2)),
          quantidadeAcoes: qtd,
          dividendYield: dy,
          dividendo12mPorAcao: s.dividendo12mPorAcao || Number(((s.cotacao * dy) / 100).toFixed(2)),
          receitaLiquida12m: s.receitaLiquida12m || 15000000000,
          proventosAnuaisEstimados: Number(provAno.toFixed(2)),
          mesesPagamento: s.papel === 'ITUB4' ? ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'] : months,
          frequencia: s.frequenciaDividendos || 'Trimestral',
          justificativa: `Alta previsibilidade com ROIC de ${s.roic}% e geração de proventos sustentável.`
        };
      });

      const avgYield = Number(((totalAnnual / invCapital) * 100).toFixed(2));
      const monthlyAvg = Number((totalAnnual / 12).toFixed(2));

      const monthsNames = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
      const cronograma = monthsNames.map(m => {
        const payers = assets.filter(a => a.mesesPagamento.includes(m)).map(a => a.papel);
        const val = payers.length > 0 ? monthlyAvg * (0.8 + Math.random() * 0.4) : monthlyAvg * 0.6;
        return {
          mes: m,
          valorEstimado: Number(val.toFixed(2)),
          pagadores: payers.length > 0 ? payers : [assets[0]?.papel || 'BBAS3']
        };
      });

      return {
        nomeCarteira: isIncome ? 'Carteira B3 Renda Perpétua & Previsibilidade' : 'Carteira Alpha Dividend Growth B3',
        estrategia: isIncome
          ? 'Estratégia focada na blindagem patrimonial através de empresas com monopólios naturais ou concessões de longo prazo. O objetivo principal é gerar um fluxo ininterrupto de proventos mensais e trimestrais com yield médio superior à renda fixa.'
          : 'Estratégia que combina empresas com alto dividend yield e histórico consolidado de crescimento dos lucros e ROIC. Além do fluxo de caixa imediato, busca-se a valorização expressiva das cotas no longo prazo.',
        dividendYieldMedio: avgYield,
        rendaAnualEstimada: Number(totalAnnual.toFixed(2)),
        rendaMensalMedia: monthlyAvg,
        ativos: assets,
        cronogramaMensal: cronograma,
        simulacaoBolaDeNeve: calcSnowball(avgYield),
        conselhoEstrategico: monthlyAdd > 0
          ? `Excelente decisão de aportar R$ ${monthlyAdd.toLocaleString('pt-BR')} mensalmente! Somado ao reinvestimento dos dividendos, você acelerará a bola de neve de juros compostos reduzindo drasticamente o tempo necessário para alcançar a liberdade financeira.`
          : 'Reinvista religiosamente os proventos recebidos na própria empresa ou no ativo mais descontado da carteira no momento do pagamento para acelerar a bola de neve de juros compostos.'
      };
    };

    if (Date.now() < geminiQuotaCooldownUntil || !ai) {
      return res.json(buildDeterministicPortfolio());
    }

    try {
      const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'Você é um planejador financeiro CFP e gestor de fundos de dividendos certificado no Brasil.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            nomeCarteira: { type: Type.STRING },
            estrategia: { type: Type.STRING },
            dividendYieldMedio: { type: Type.NUMBER },
            rendaAnualEstimada: { type: Type.NUMBER },
            rendaMensalMedia: { type: Type.NUMBER },
            ativos: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  papel: { type: Type.STRING },
                  nomeEmpresa: { type: Type.STRING },
                  setor: { type: Type.STRING },
                  peso: { type: Type.NUMBER },
                  valorAlocado: { type: Type.NUMBER },
                  quantidadeAcoes: { type: Type.NUMBER },
                  dividendYield: { type: Type.NUMBER },
                  dividendo12mPorAcao: { type: Type.NUMBER },
                  receitaLiquida12m: { type: Type.NUMBER },
                  proventosAnuaisEstimados: { type: Type.NUMBER },
                  mesesPagamento: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  frequencia: { type: Type.STRING },
                  justificativa: { type: Type.STRING }
                },
                required: ['papel', 'nomeEmpresa', 'setor', 'peso', 'valorAlocado', 'quantidadeAcoes', 'dividendYield', 'proventosAnuaisEstimados', 'mesesPagamento', 'frequencia', 'justificativa']
              }
            },
            cronogramaMensal: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  mes: { type: Type.STRING },
                  valorEstimado: { type: Type.NUMBER },
                  pagadores: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: ['mes', 'valorEstimado', 'pagadores']
              }
            },
            simulacaoBolaDeNeve: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  ano: { type: Type.NUMBER },
                  totalInvestido: { type: Type.NUMBER },
                  patrimonioProjetado: { type: Type.NUMBER },
                  rendaMensalProjetada: { type: Type.NUMBER }
                },
                required: ['ano', 'totalInvestido', 'patrimonioProjetado', 'rendaMensalProjetada']
              }
            },
            conselhoEstrategico: { type: Type.STRING }
          },
          required: [
            'nomeCarteira',
            'estrategia',
            'dividendYieldMedio',
            'rendaAnualEstimada',
            'rendaMensalMedia',
            'ativos',
            'cronogramaMensal',
            'simulacaoBolaDeNeve',
            'conselhoEstrategico'
          ]
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    const safeYield = typeof parsed.dividendYieldMedio === 'number' && parsed.dividendYieldMedio > 0
      ? parsed.dividendYieldMedio
      : 8.0;
    parsed.simulacaoBolaDeNeve = calcSnowball(safeYield);
    return res.json(parsed);
  } catch (error: any) {
    const errorStr = String(error?.message || error || '');
    if (errorStr.includes('429') || errorStr.includes('quota') || errorStr.includes('RESOURCE_EXHAUSTED')) {
      geminiQuotaCooldownUntil = Date.now() + 1000 * 60 * 60; // 1h cooldown
      console.log('[Portfolio AI] Gemini API free-tier quota limit reached. Serving verified deterministic financial model.');
    } else {
      console.log('[Portfolio AI] Serving deterministic financial model.');
    }
    return res.json(buildDeterministicPortfolio());
  }
});

// Configure Vite integration for dev server or static serve in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`B3 AlphaTerminal server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
