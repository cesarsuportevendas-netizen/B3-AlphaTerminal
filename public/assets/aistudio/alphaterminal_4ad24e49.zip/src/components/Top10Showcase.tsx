import React, { useState } from 'react';
import { StockIndicator, RankingWeights } from '../types/stock';
import { formatCurrency, formatPercent } from '../utils/financialCalculations';
import { Sparkles, ArrowUpRight, ShieldCheck, DollarSign, SlidersHorizontal, Activity } from 'lucide-react';

interface Top10ShowcaseProps {
  stocks: StockIndicator[];
  onSelectStockForAI: (stock: StockIndicator) => void;
  weights: RankingWeights;
  onUpdateWeights: (newWeights: RankingWeights) => void;
}

export const Top10Showcase: React.FC<Top10ShowcaseProps> = ({
  stocks,
  onSelectStockForAI,
  weights,
  onUpdateWeights,
}) => {
  const [filterStrategy, setFilterStrategy] = useState<'geral' | 'greenblatt' | 'bazin' | 'graham' | 'smartmoney'>('geral');
  const [showSliders, setShowSliders] = useState(false);

  // Compute filtered top 10 based on selected strategy
  const top10 = React.useMemo(() => {
    let sorted = [...stocks];
    if (filterStrategy === 'greenblatt') {
      // Magic Formula: menor P/L positivo + maior ROIC
      sorted.sort((a, b) => {
        const plA = a.pl > 0 ? a.pl : 999;
        const plB = b.pl > 0 ? b.pl : 999;
        return plA - plB - (a.roic - b.roic) * 0.5;
      });
    } else if (filterStrategy === 'bazin') {
      // Bazin: Maior Dividend Yield com margem > 10%
      sorted.sort((a, b) => b.divYield - a.divYield);
    } else if (filterStrategy === 'graham') {
      // Graham: Maior desconto sobre o Preço Justo de Graham
      sorted.sort((a, b) => b.descontoGrahamPerc - a.descontoGrahamPerc);
    } else if (filterStrategy === 'smartmoney') {
      // Fluxo dos Tubarões
      sorted.sort((a, b) => b.smartMoneyScore - a.smartMoneyScore);
    } else {
      // Score Alpha consolidado
      sorted.sort((a, b) => b.scoreAlpha - a.scoreAlpha);
    }
    return sorted.slice(0, 10);
  }, [stocks, filterStrategy]);

  const handleApplyPreset = (preset: 'balanceado' | 'dividendos' | 'valor' | 'qualidade') => {
    if (preset === 'balanceado') {
      onUpdateWeights({ pesoRentabilidade: 30, pesoValuation: 25, pesoDividendos: 15, pesoSaudeFinanceira: 15, pesoSmartMoney: 15 });
    } else if (preset === 'dividendos') {
      onUpdateWeights({ pesoRentabilidade: 20, pesoValuation: 20, pesoDividendos: 40, pesoSaudeFinanceira: 10, pesoSmartMoney: 10 });
    } else if (preset === 'valor') {
      onUpdateWeights({ pesoRentabilidade: 15, pesoValuation: 50, pesoDividendos: 15, pesoSaudeFinanceira: 10, pesoSmartMoney: 10 });
    } else if (preset === 'qualidade') {
      onUpdateWeights({ pesoRentabilidade: 45, pesoValuation: 15, pesoDividendos: 10, pesoSaudeFinanceira: 15, pesoSmartMoney: 15 });
    }
  };

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-emerald-400 font-mono tracking-wider uppercase mb-1">
            <span>Seleção Quantitativa Oficial B3</span>
            <span aria-hidden="true">·</span>
            <span>Atualização em Tempo Real</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Os 10 Ativos Mais Bem Analisados
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-3xl">
            Classificação algorítmica calculada a partir dos dados fundamentalistas da imagem, integrando modelos de Benjamin Graham, Décio Bazin, Fórmula Mágica de Greenblatt e rastreamento de fluxo de grandes investidores.
          </p>
        </div>

        {/* Filter Controls (Segmented bar without static pill boxes) */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs">
            <button
              onClick={() => setFilterStrategy('geral')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                filterStrategy === 'geral' ? 'bg-emerald-500/20 text-emerald-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Alpha Geral
            </button>
            <button
              onClick={() => setFilterStrategy('greenblatt')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                filterStrategy === 'greenblatt' ? 'bg-emerald-500/20 text-emerald-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Fórmula Mágica
            </button>
            <button
              onClick={() => setFilterStrategy('bazin')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                filterStrategy === 'bazin' ? 'bg-emerald-500/20 text-emerald-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Dividendos (Bazin)
            </button>
            <button
              onClick={() => setFilterStrategy('graham')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                filterStrategy === 'graham' ? 'bg-emerald-500/20 text-emerald-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Desconto Graham
            </button>
            <button
              onClick={() => setFilterStrategy('smartmoney')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                filterStrategy === 'smartmoney' ? 'bg-emerald-500/20 text-emerald-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Fluxo Tubarões
            </button>
          </div>

          <button
            onClick={() => setShowSliders(!showSliders)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Ponderar Indicadores</span>
          </button>
        </div>
      </div>

      {/* Customizable Weights Drawer */}
      {showSliders && (
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-200">
              Calibração de Pesos dos Indicadores
            </span>
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-slate-400">Presets:</span>
              <button
                onClick={() => handleApplyPreset('balanceado')}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Balanceado
              </button>
              <button
                onClick={() => handleApplyPreset('dividendos')}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Foco Proventos
              </button>
              <button
                onClick={() => handleApplyPreset('valor')}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Deep Value
              </button>
              <button
                onClick={() => handleApplyPreset('qualidade')}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Qualidade / ROIC
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Rentabilidade (ROIC/ROE)</span>
                <span className="font-mono text-emerald-400">{weights.pesoRentabilidade}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={weights.pesoRentabilidade}
                onChange={(e) => onUpdateWeights({ ...weights, pesoRentabilidade: Number(e.target.value) })}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Valuation (P/L, P/VP, EV)</span>
                <span className="font-mono text-emerald-400">{weights.pesoValuation}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={weights.pesoValuation}
                onChange={(e) => onUpdateWeights({ ...weights, pesoValuation: Number(e.target.value) })}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Dividendos (Div. Yield)</span>
                <span className="font-mono text-emerald-400">{weights.pesoDividendos}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={weights.pesoDividendos}
                onChange={(e) => onUpdateWeights({ ...weights, pesoDividendos: Number(e.target.value) })}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Saúde (Dívida / Liq.)</span>
                <span className="font-mono text-emerald-400">{weights.pesoSaudeFinanceira}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={weights.pesoSaudeFinanceira}
                onChange={(e) => onUpdateWeights({ ...weights, pesoSaudeFinanceira: Number(e.target.value) })}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Fluxo Grandes Investidores</span>
                <span className="font-mono text-emerald-400">{weights.pesoSmartMoney}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={weights.pesoSmartMoney}
                onChange={(e) => onUpdateWeights({ ...weights, pesoSmartMoney: Number(e.target.value) })}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* Top 10 Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {top10.map((stock, idx) => (
          <div
            key={stock.id}
            className="p-5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
          >
            {/* Card Header */}
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <div className="w-8 h-8 shrink-0 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-bold text-sm text-emerald-400 mt-0.5">
                    #{idx + 1}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline gap-2 flex-wrap">
                      <span className="text-xl font-bold tracking-tight text-white font-mono">
                        {stock.papel}
                      </span>
                      <span className="text-sm font-mono text-slate-300">
                        {formatCurrency(stock.cotacao)}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 leading-snug break-words whitespace-normal mt-0.5">
                      {stock.nomeEmpresa}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-xs text-slate-400">Score Alpha</div>
                  <div className="text-xl font-bold font-mono text-emerald-400">
                    {stock.scoreAlpha}
                    <span className="text-xs text-slate-500">/100</span>
                  </div>
                </div>
              </div>

              {/* Unboxed Metadata & Sector Line */}
              <div className="flex items-center flex-wrap gap-2 text-xs text-slate-400 mt-2 pb-3 border-b border-slate-800/80">
                <span>{stock.setor}</span>
                <span aria-hidden="true">·</span>
                <span>{stock.subsetor}</span>
                <span aria-hidden="true">·</span>
                <span>{stock.governanca}</span>
              </div>

              {/* Fundamental Metrics Matrix (Divided into responsive rows) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 my-3 text-xs">
                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <div className="text-slate-400 text-[11px]">P/L</div>
                  <div className="font-mono font-semibold text-slate-200 mt-0.5">
                    {stock.pl.toFixed(2)}
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <div className="text-slate-400 text-[11px]">ROIC</div>
                  <div className="font-mono font-semibold text-emerald-400 mt-0.5">
                    {formatPercent(stock.roic)}
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <div className="text-slate-400 text-[11px]">DY (12m)</div>
                  <div className="font-mono font-semibold text-amber-300 mt-0.5">
                    {formatPercent(stock.divYield)}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono mt-0.5">
                    R$ {(stock.dividendo12mPorAcao || ((stock.cotacao * stock.divYield) / 100)).toFixed(2)}/aç
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <div className="text-slate-400 text-[11px]">P/VP</div>
                  <div className="font-mono font-semibold text-slate-200 mt-0.5">
                    {stock.pvp.toFixed(2)}
                  </div>
                </div>
              </div>

              {/* Trade Points (Entry, Stop, Target) - Divided cleanly into lines */}
              <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 space-y-1.5 text-xs font-mono">
                <div className="flex items-center justify-between gap-2 flex-wrap text-slate-300">
                  <span className="text-slate-400">Ponto de Entrada Sugerido:</span>
                  <span className="font-semibold text-emerald-400">{formatCurrency(stock.pontoEntrada)}</span>
                </div>
                <div className="flex items-center justify-between gap-2 flex-wrap text-slate-300">
                  <span className="text-slate-400">Stop Loss Técnico:</span>
                  <span className="font-semibold text-rose-400">{formatCurrency(stock.stopLoss)}</span>
                </div>
                <div className="flex items-center justify-between gap-2 flex-wrap text-slate-300">
                  <span className="text-slate-400">Alvo 1 (Curto Prazo):</span>
                  <span className="font-semibold text-cyan-300">{formatCurrency(stock.alvo1CurtoPrazo)}</span>
                </div>
                <div className="flex items-center justify-between gap-2 flex-wrap text-slate-300">
                  <span className="text-slate-400">Risco / Retorno:</span>
                  <span className="text-slate-200 font-bold">{stock.riscoRetorno}</span>
                </div>
              </div>

              {/* Smart Money Footprint Line */}
              <div className="mt-3 text-xs text-slate-400 flex items-center justify-between gap-2 flex-wrap">
                <span className="break-words">Padrão Institucional: <strong className="text-slate-200 font-medium">{stock.padraoWyckoff}</strong></span>
                <span className="font-mono text-emerald-400 whitespace-nowrap">Fluxo: {stock.smartMoneyScore}/100</span>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div className="text-xs text-slate-400">
                Preço Justo Graham: <span className="font-mono text-slate-200 font-semibold">{formatCurrency(stock.precoJustoGraham)}</span>
              </div>
              <button
                onClick={() => onSelectStockForAI(stock)}
                className="flex items-center justify-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-xs font-semibold rounded-lg border border-emerald-500/30 transition-colors whitespace-nowrap"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Previsão de IA & Gráficos</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
