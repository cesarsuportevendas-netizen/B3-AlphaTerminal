import React from 'react';
import { TrendingUp, Bell, Download, Upload, Sparkles, DollarSign, Briefcase } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenCSVImport: () => void;
  onExportCSV: () => void;
  onPrintReport: () => void;
  unreadAlertsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenCSVImport,
  onExportCSV,
  onPrintReport,
  unreadAlertsCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-8 h-16">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <TrendingUp className="w-5 h-5" />
          </div>
          <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap">
            B3 AlphaTerminal
          </span>
        </div>

        {/* Zone 2: Navigation Links (Single line, whitespace-nowrap, responsive gap) */}
        <nav className="hidden lg:flex items-center gap-3.5 xl:gap-5 text-xs xl:text-sm font-medium">
          <button
            onClick={() => setActiveTab('top10')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'top10'
                ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Destaques Top 10
          </button>

          <button
            onClick={() => setActiveTab('custom-portfolio')}
            className={`whitespace-nowrap transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'custom-portfolio'
                ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
            <span>Minha Carteira</span>
          </button>

          <button
            onClick={() => setActiveTab('portfolios')}
            className={`whitespace-nowrap transition-colors py-1 flex items-center gap-1 ${
              activeTab === 'portfolios'
                ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            <span>Carteiras & IA</span>
          </button>

          <button
            onClick={() => setActiveTab('spreadsheet')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'spreadsheet'
                ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Planilha
          </button>

          <button
            onClick={() => setActiveTab('smartmoney')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'smartmoney'
                ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Tubarões & Fluxo
          </button>

          <button
            onClick={() => setActiveTab('ai-forecast')}
            className={`whitespace-nowrap transition-colors py-1 flex items-center gap-1 ${
              activeTab === 'ai-forecast'
                ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Previsões IA</span>
          </button>

          <button
            onClick={() => setActiveTab('alerts')}
            className={`whitespace-nowrap transition-colors py-1 flex items-center gap-1 ${
              activeTab === 'alerts'
                ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Alertas</span>
            {unreadAlertsCount > 0 && (
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded font-mono">
                {unreadAlertsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'reports'
                ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Relatórios
          </button>
        </nav>

        {/* Zone 3: Primary Action Button - Importar CSV */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenCSVImport}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-colors whitespace-nowrap"
          >
            <Upload className="w-4 h-4" />
            <span>Importar CSV</span>
          </button>
        </div>
      </div>

      {/* Mobile navigation tab strip */}
      <div className="lg:hidden flex items-center gap-2 overflow-x-auto px-4 py-2 border-t border-slate-800 bg-slate-900 text-xs">
        {[
          { id: 'top10', label: 'Top 10' },
          { id: 'custom-portfolio', label: 'Minha Carteira' },
          { id: 'portfolios', label: 'Carteiras IA' },
          { id: 'spreadsheet', label: 'Planilha' },
          { id: 'smartmoney', label: 'Tubarões' },
          { id: 'ai-forecast', label: 'IA & Trades' },
          { id: 'alerts', label: 'Alertas' },
          { id: 'reports', label: 'Relatórios' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-1 rounded-md whitespace-nowrap font-medium ${
              activeTab === tab.id
                ? 'bg-emerald-500/20 text-emerald-300'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </header>
  );
};
