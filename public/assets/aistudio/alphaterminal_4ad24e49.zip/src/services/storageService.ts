import { StockIndicator } from '../types/stock';
import { INITIAL_STOCKS } from '../data/initialStocks';
import { calculateRankings } from '../utils/financialCalculations';

const STORAGE_KEY = 'b3_alpha_terminal_stocks_v1';
const ALERTS_KEY = 'b3_alpha_terminal_alerts_v1';

export function getStoredStocks(): StockIndicator[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial = calculateRankings(INITIAL_STOCKS);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return calculateRankings(parsed);
    }
    return calculateRankings(INITIAL_STOCKS);
  } catch (err) {
    console.error('Failed to load stocks from storage:', err);
    return calculateRankings(INITIAL_STOCKS);
  }
}

export function saveStocks(stocks: StockIndicator[]): void {
  try {
    const recalculated = calculateRankings(stocks);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(recalculated));
  } catch (err) {
    console.error('Failed to save stocks to storage:', err);
  }
}

export function resetToInitialStocks(): StockIndicator[] {
  const recalculated = calculateRankings(INITIAL_STOCKS);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(recalculated));
  return recalculated;
}

export function exportStocksToCSV(stocks: StockIndicator[]): void {
  const headers = [
    'Papel',
    'Empresa',
    'Setor',
    'Cotacao (R$)',
    'P/L',
    'P/VP',
    'Div. Yield (%)',
    'DPA 12m (R$)',
    'ROIC (%)',
    'ROE (%)',
    'Margem Liq (%)',
    'Receita 12m (R$)',
    'EV/EBIT',
    'Patrimonio Liq',
    'Liquidez 2 Meses',
    'Score Alpha',
    'Posicao Top 10',
    'Ponto Entrada (R$)',
    'Stop Loss (R$)',
    'Alvo 1 (R$)',
    'Alvo 2 (R$)',
    'Fluxo Institucional',
    'Padrao Wyckoff',
    'Smart Money Score'
  ];

  const rows = stocks.map(s => [
    `"${s.papel}"`,
    `"${s.nomeEmpresa.replace(/"/g, '""')}"`,
    `"${s.setor}"`,
    s.cotacao.toFixed(2).replace('.', ','),
    s.pl.toFixed(2).replace('.', ','),
    s.pvp.toFixed(2).replace('.', ','),
    s.divYield.toFixed(2).replace('.', ','),
    (s.dividendo12mPorAcao || ((s.cotacao * s.divYield) / 100)).toFixed(2).replace('.', ','),
    s.roic.toFixed(2).replace('.', ','),
    s.roe.toFixed(2).replace('.', ','),
    s.margLiquida.toFixed(2).replace('.', ','),
    s.receitaLiquida12m || 0,
    s.evEbit.toFixed(2).replace('.', ','),
    s.patrimLiq,
    s.liq2m,
    s.scoreAlpha,
    s.posicaoTop10 || '-',
    s.pontoEntrada.toFixed(2).replace('.', ','),
    s.stopLoss.toFixed(2).replace('.', ','),
    s.alvo1CurtoPrazo.toFixed(2).replace('.', ','),
    s.alvo2LongoPrazo.toFixed(2).replace('.', ','),
    `"${s.principaisAcionistas.replace(/"/g, '""')}"`,
    `"${s.padraoWyckoff}"`,
    s.smartMoneyScore
  ]);

  const csvContent = '\uFEFF' + [headers.join(';'), ...rows.map(r => r.join(';'))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `b3_alphaterminal_analise_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
