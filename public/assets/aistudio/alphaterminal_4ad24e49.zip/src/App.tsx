import React, { useState, useEffect } from 'react';
import { StockIndicator, RankingWeights, CustomAlert } from './types/stock';
import {
  getStoredStocks,
  saveStocks,
  resetToInitialStocks,
  exportStocksToCSV,
} from './services/storageService';
import { calculateRankings, DEFAULT_WEIGHTS } from './utils/financialCalculations';
import { Header } from './components/Header';
import { Top10Showcase } from './components/Top10Showcase';
import { AIPortfolioBuilder } from './components/AIPortfolioBuilder';
import { StockSpreadsheet } from './components/StockSpreadsheet';
import { InstitutionalFlowTracker } from './components/InstitutionalFlowTracker';
import { AITrendForecast } from './components/AITrendForecast';
import { CustomPortfolioManager } from './components/CustomPortfolioManager';
import { AlertsManager } from './components/AlertsManager';
import { ExecutiveReportView } from './components/ExecutiveReportView';
import { CSVImportModal } from './components/CSVImportModal';
import { NotificationBanner, ActiveNotification } from './components/NotificationBanner';

export default function App() {
  const [stocks, setStocks] = useState<StockIndicator[]>(() => getStoredStocks());
  const [activeTab, setActiveTab] = useState<string>('top10');
  const [previousTab, setPreviousTab] = useState<string>('top10');
  const [weights, setWeights] = useState<RankingWeights>(DEFAULT_WEIGHTS);
  const [selectedStockForAI, setSelectedStockForAI] = useState<StockIndicator>(
    () => stocks[0] || ({} as StockIndicator)
  );
  const [isCSVImportOpen, setIsCSVImportOpen] = useState(false);
  const [activeNotifications, setActiveNotifications] = useState<ActiveNotification[]>([]);

  const TAB_LABELS: Record<string, string> = {
    top10: 'Destaques Top 10',
    'custom-portfolio': 'Minha Carteira',
    portfolios: 'Carteiras & Renda',
    spreadsheet: 'Planilha de Ativos',
    smartmoney: 'Tubarões & Fluxo',
    'ai-forecast': 'Previsões IA',
    alerts: 'Alertas',
    reports: 'Relatórios Executivos',
  };

  // Persistent user alerts
  const [alerts, setAlerts] = useState<CustomAlert[]>(() => {
    try {
      const raw = localStorage.getItem('b3_alpha_terminal_alerts_v1');
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return [
      {
        id: 'alert_1',
        stockTicker: 'PETR4',
        tipo: 'ponto_entrada',
        valorGatilho: 37.80,
        ativo: true,
        mensagem: 'PETR4 atingiu o Ponto de Entrada técnico ideal em R$ 37,80',
        criadoEm: '03/11/2026',
      },
      {
        id: 'alert_2',
        stockTicker: 'BBAS3',
        tipo: 'acumulacao_tubaroes',
        valorGatilho: 90,
        ativo: true,
        mensagem: 'Forte Acumulação Silenciosa institucional detectada em BBAS3',
        criadoEm: '03/11/2026',
      },
      {
        id: 'alert_3',
        stockTicker: 'VALE3',
        tipo: 'dy_acima',
        valorGatilho: 8.5,
        ativo: true,
        mensagem: 'VALE3 superou Dividend Yield de 8,5%',
        criadoEm: '03/11/2026',
      },
    ];
  });

  // Save alerts to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('b3_alpha_terminal_alerts_v1', JSON.stringify(alerts));
    } catch (e) {}
  }, [alerts]);

  // Recalculate rankings whenever weights change
  const handleUpdateWeights = (newWeights: RankingWeights) => {
    setWeights(newWeights);
    const updated = calculateRankings(stocks, newWeights);
    setStocks(updated);
    saveStocks(updated);
  };

  // Stock CRUD & CSV Import
  const handleUpdateStock = (updated: StockIndicator) => {
    const nextList = stocks.map((s) => (s.id === updated.id ? updated : s));
    const recalculated = calculateRankings(nextList, weights);
    setStocks(recalculated);
    saveStocks(recalculated);

    if (selectedStockForAI.id === updated.id) {
      setSelectedStockForAI(updated);
    }
  };

  const handleDeleteStock = (id: string) => {
    const nextList = stocks.filter((s) => s.id !== id);
    const recalculated = calculateRankings(nextList, weights);
    setStocks(recalculated);
    saveStocks(recalculated);
  };

  const handleImportStocks = (imported: StockIndicator[], replaceAll: boolean) => {
    let nextList: StockIndicator[];
    if (replaceAll) {
      nextList = imported;
    } else {
      const map = new Map<string, StockIndicator>();
      stocks.forEach((s) => map.set(s.papel, s));
      imported.forEach((s) => map.set(s.papel, { ...map.get(s.papel), ...s }));
      nextList = Array.from(map.values());
    }
    const recalculated = calculateRankings(nextList, weights);
    setStocks(recalculated);
    saveStocks(recalculated);
    if (recalculated[0]) setSelectedStockForAI(recalculated[0]);
  };

  const handleResetStocks = () => {
    const fresh = resetToInitialStocks();
    setStocks(fresh);
    if (fresh[0]) setSelectedStockForAI(fresh[0]);
  };

  // Navigation & AI Selection
  const handleNavigateTab = (tab: string) => {
    if (tab !== activeTab) {
      setPreviousTab(activeTab);
      setActiveTab(tab);
    }
  };

  const handleSelectStockForAI = (stock: StockIndicator) => {
    setPreviousTab(activeTab);
    setSelectedStockForAI(stock);
    setActiveTab('ai-forecast');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackFromAI = () => {
    const target = previousTab && previousTab !== 'ai-forecast' ? previousTab : 'top10';
    setActiveTab(target);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Alert Actions & Push Trigger
  const handleAddAlert = (alert: CustomAlert) => {
    setAlerts((prev) => [alert, ...prev]);
  };

  const handleToggleAlert = (id: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, ativo: !a.ativo } : a))
    );
  };

  const handleDeleteAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  const triggerNotification = (
    stock: StockIndicator,
    title: string,
    body: string
  ) => {
    // 1. Native Web Push Notification (if permitted)
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        try {
          new Notification(title, {
            body,
            icon: '/favicon.ico',
          });
        } catch (e) {
          console.warn('Native notification failed:', e);
        }
      }
    }

    // 2. In-App Toast Banner
    const notif: ActiveNotification = {
      id: 'notif_' + Date.now(),
      title,
      body,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    };

    setActiveNotifications((prev) => [notif, ...prev.slice(0, 3)]);

    setTimeout(() => {
      setActiveNotifications((prev) => prev.filter((n) => n.id !== notif.id));
    }, 6000);
  };

  const handleDismissNotification = (id: string) => {
    setActiveNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* 3-Zone Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={handleNavigateTab}
        onOpenCSVImport={() => setIsCSVImportOpen(true)}
        onExportCSV={() => exportStocksToCSV(stocks)}
        onPrintReport={() => handleNavigateTab('reports')}
        unreadAlertsCount={alerts.filter((a) => a.ativo).length}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'top10' && (
          <Top10Showcase
            stocks={stocks}
            onSelectStockForAI={handleSelectStockForAI}
            weights={weights}
            onUpdateWeights={handleUpdateWeights}
          />
        )}

        {activeTab === 'custom-portfolio' && (
          <CustomPortfolioManager
            stocks={stocks}
            onBack={handleBackFromAI}
            previousTabTitle={TAB_LABELS[previousTab] || 'Destaques Top 10'}
            onSelectStockForAI={handleSelectStockForAI}
          />
        )}

        {activeTab === 'portfolios' && (
          <AIPortfolioBuilder
            stocks={stocks}
            onSelectStockForAI={handleSelectStockForAI}
          />
        )}

        {activeTab === 'spreadsheet' && (
          <StockSpreadsheet
            stocks={stocks}
            onUpdateStock={handleUpdateStock}
            onDeleteStock={handleDeleteStock}
            onResetStocks={handleResetStocks}
            onExportCSV={() => exportStocksToCSV(stocks)}
            onOpenCSVImport={() => setIsCSVImportOpen(true)}
            onSelectStockForAI={handleSelectStockForAI}
          />
        )}

        {activeTab === 'smartmoney' && (
          <InstitutionalFlowTracker
            stocks={stocks}
            onSelectStockForAI={handleSelectStockForAI}
          />
        )}

        {activeTab === 'ai-forecast' && (
          <AITrendForecast
            stocks={stocks}
            selectedStock={selectedStockForAI}
            onSelectStock={setSelectedStockForAI}
            onBack={handleBackFromAI}
            previousTabTitle={TAB_LABELS[previousTab] || 'Destaques Top 10'}
          />
        )}

        {activeTab === 'alerts' && (
          <AlertsManager
            stocks={stocks}
            alerts={alerts}
            onAddAlert={handleAddAlert}
            onToggleAlert={handleToggleAlert}
            onDeleteAlert={handleDeleteAlert}
            onTriggerTestAlert={triggerNotification}
          />
        )}

        {activeTab === 'reports' && (
          <ExecutiveReportView
            stocks={stocks}
            onExportCSV={() => exportStocksToCSV(stocks)}
          />
        )}
      </main>

      {/* CSV Import Modal (Replaces individual asset entry) */}
      <CSVImportModal
        isOpen={isCSVImportOpen}
        onClose={() => setIsCSVImportOpen(false)}
        onImportStocks={handleImportStocks}
      />

      {/* Toast Push Notification Banner */}
      <NotificationBanner
        notifications={activeNotifications}
        onDismiss={handleDismissNotification}
      />
    </div>
  );
}
