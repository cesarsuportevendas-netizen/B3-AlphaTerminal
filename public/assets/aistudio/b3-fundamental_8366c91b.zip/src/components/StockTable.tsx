import React, { useState, useMemo } from 'react';
import {
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Search,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { StockData } from '../types/stock';
import {
  formatCurrency,
  formatPercent,
  formatNumber,
  formatCompactNumber,
} from '../utils/dataCleaner';

interface StockTableProps {
  stocks: StockData[];
  onSelectStock: (stock: StockData) => void;
}

type SortField =
  | 'papel'
  | 'cotacao'
  | 'pl'
  | 'pvp'
  | 'psr'
  | 'divYield'
  | 'evEbitda'
  | 'mrgEbit'
  | 'mrgLiq'
  | 'roic'
  | 'roe'
  | 'liqCorr'
  | 'divLiqPatrim'
  | 'liq2meses'
  | 'patrimLiq'
  | 'crescRec5a';

export const StockTable: React.FC<StockTableProps> = ({ stocks, onSelectStock }) => {
  const [sortField, setSortField] = useState<SortField>('liq2meses');
  const [sortAsc, setSortAsc] = useState<boolean>(false);
  const [tableSearch, setTableSearch] = useState<string>('');
  const [pageSize, setPageSize] = useState<number>(15);
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Sorting handler
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      // Sensible defaults: numbers descending first, text ascending first
      setSortAsc(field === 'papel');
    }
  };

  // Filtered and sorted data
  const processedData = useMemo(() => {
    let result = stocks;

    if (tableSearch.trim()) {
      const q = tableSearch.toLowerCase();
      result = result.filter(
        (s) =>
          s.papel.toLowerCase().includes(q) ||
          (s.nomeEmpresa && s.nomeEmpresa.toLowerCase().includes(q)) ||
          s.setor.toLowerCase().includes(q)
      );
    }

    return [...result].sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];

      // Handle nulls always at bottom
      if (valA === null || valA === undefined) return 1;
      if (valB === null || valB === undefined) return -1;

      if (typeof valA === 'string' && typeof valB === 'string') {
        return sortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
      }

      const numA = Number(valA);
      const numB = Number(valB);
      return sortAsc ? numA - numB : numB - numA;
    });
  }, [stocks, tableSearch, sortField, sortAsc]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(processedData.length / pageSize));
  const pageIndex = Math.min(currentPage, totalPages);
  const pageData = processedData.slice((pageIndex - 1) * pageSize, pageIndex * pageSize);

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3 h-3 text-slate-600 opacity-60" />;
    }
    return sortAsc ? (
      <ArrowUp className="w-3 h-3 text-emerald-400" />
    ) : (
      <ArrowDown className="w-3 h-3 text-emerald-400" />
    );
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
      {/* Header controls: Search and Page size */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Filtrar nesta tabela..."
              value={tableSearch}
              onChange={(e) => {
                setTableSearch(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-md text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-emerald-500"
            />
          </div>
          <span className="text-xs text-slate-400 font-mono whitespace-nowrap">
            {processedData.length} registros
          </span>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto text-xs text-slate-400">
          <span>Linhas por página:</span>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-white font-mono focus:outline-hidden"
          >
            <option value={15}>15</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
      </div>

      {/* Main Data Grid */}
      <div className="overflow-x-auto border border-slate-800 rounded-md">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-950/90 text-[11px] text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800 select-none">
            <tr>
              <th
                onClick={() => handleSort('papel')}
                className="py-3 px-3 cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Papel</span>
                  {renderSortIcon('papel')}
                </div>
              </th>
              <th
                onClick={() => handleSort('cotacao')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Cotação</span>
                  {renderSortIcon('cotacao')}
                </div>
              </th>
              <th
                onClick={() => handleSort('pl')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>P/L</span>
                  {renderSortIcon('pl')}
                </div>
              </th>
              <th
                onClick={() => handleSort('pvp')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>P/VP</span>
                  {renderSortIcon('pvp')}
                </div>
              </th>
              <th
                onClick={() => handleSort('divYield')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>DY (%)</span>
                  {renderSortIcon('divYield')}
                </div>
              </th>
              <th
                onClick={() => handleSort('evEbitda')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>EV/EBITDA</span>
                  {renderSortIcon('evEbitda')}
                </div>
              </th>
              <th
                onClick={() => handleSort('roic')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>ROIC</span>
                  {renderSortIcon('roic')}
                </div>
              </th>
              <th
                onClick={() => handleSort('roe')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>ROE</span>
                  {renderSortIcon('roe')}
                </div>
              </th>
              <th
                onClick={() => handleSort('mrgLiq')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Mrg. Líq.</span>
                  {renderSortIcon('mrgLiq')}
                </div>
              </th>
              <th
                onClick={() => handleSort('divLiqPatrim')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Dív.Líq/PL</span>
                  {renderSortIcon('divLiqPatrim')}
                </div>
              </th>
              <th
                onClick={() => handleSort('liqCorr')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Liq. Corr.</span>
                  {renderSortIcon('liqCorr')}
                </div>
              </th>
              <th
                onClick={() => handleSort('liq2meses')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Liq. 2m</span>
                  {renderSortIcon('liq2meses')}
                </div>
              </th>
              <th
                onClick={() => handleSort('patrimLiq')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Patrim. Líq</span>
                  {renderSortIcon('patrimLiq')}
                </div>
              </th>
              <th
                onClick={() => handleSort('crescRec5a')}
                className="py-3 px-3 text-right cursor-pointer hover:text-white transition-colors"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Cresc. 5a</span>
                  {renderSortIcon('crescRec5a')}
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {pageData.length === 0 ? (
              <tr>
                <td colSpan={14} className="py-8 text-center text-slate-500 font-sans">
                  Nenhuma ação encontrada com os filtros atuais.
                </td>
              </tr>
            ) : (
              pageData.map((stock) => {
                const isOverleveraged = (stock.divLiqPatrim || 0) > 1.5;
                const isLowLiquidity = (stock.liqCorr || 0) < 1.0 && (stock.liqCorr || 0) > 0;
                const isNetCash = (stock.divLiqPatrim || 0) < 0;

                return (
                  <tr
                    key={stock.id}
                    onClick={() => onSelectStock(stock)}
                    className="hover:bg-slate-800/60 transition-colors cursor-pointer group"
                  >
                    <td className="py-2.5 px-3 font-sans">
                      <div className="font-bold text-white group-hover:text-emerald-400 flex items-center gap-1.5">
                        <span>{stock.papel}</span>
                        <ExternalLink className="w-3 h-3 text-slate-600 group-hover:text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <span className="block text-[10px] text-slate-400 truncate max-w-[130px]">
                        {stock.nomeEmpresa || stock.setor}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-semibold text-white">
                      {formatCurrency(stock.cotacao)}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.pl !== null ? (
                        <span className={stock.pl < 0 ? 'text-rose-400' : 'text-slate-200'}>
                          {formatNumber(stock.pl, 1)}x
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.pvp !== null ? (
                        <span className={stock.pvp < 1 ? 'text-emerald-400 font-medium' : 'text-slate-200'}>
                          {formatNumber(stock.pvp, 2)}x
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.divYield !== null ? (
                        <span
                          className={
                            stock.divYield >= 8
                              ? 'text-emerald-400 font-bold'
                              : stock.divYield > 0
                              ? 'text-slate-200'
                              : 'text-slate-500'
                          }
                        >
                          {formatPercent(stock.divYield, 1)}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {stock.evEbitda !== null ? `${formatNumber(stock.evEbitda, 1)}x` : '—'}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.roic !== null ? (
                        <span className={stock.roic >= 18 ? 'text-emerald-400 font-semibold' : 'text-slate-300'}>
                          {formatPercent(stock.roic, 1)}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.roe !== null ? (
                        <span className={stock.roe >= 20 ? 'text-sky-400 font-semibold' : 'text-slate-300'}>
                          {formatPercent(stock.roe, 1)}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.mrgLiq !== null ? (
                        <span className={stock.mrgLiq < 0 ? 'text-rose-400' : 'text-slate-300'}>
                          {formatPercent(stock.mrgLiq, 1)}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.divLiqPatrim !== null ? (
                        <span
                          className={
                            isOverleveraged
                              ? 'text-rose-400 font-semibold'
                              : isNetCash
                              ? 'text-emerald-400 font-medium'
                              : 'text-slate-300'
                          }
                        >
                          {formatNumber(stock.divLiqPatrim, 2)}x
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.liqCorr !== null ? (
                        <span className={isLowLiquidity ? 'text-rose-400 font-semibold' : 'text-slate-300'}>
                          {formatNumber(stock.liqCorr, 2)}x
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {formatCompactNumber(stock.liq2meses)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {formatCompactNumber(stock.patrimLiq)}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {stock.crescRec5a !== null ? (
                        <span className={stock.crescRec5a >= 15 ? 'text-sky-400 font-semibold' : 'text-slate-300'}>
                          {formatPercent(stock.crescRec5a, 1)}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-3 pt-1">
        <span>
          Página <span className="font-mono text-white font-semibold">{pageIndex}</span> de{' '}
          <span className="font-mono text-white font-semibold">{totalPages}</span>
        </span>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage(Math.max(1, pageIndex - 1))}
            disabled={pageIndex <= 1}
            className="p-1.5 rounded bg-slate-950 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setCurrentPage(Math.min(totalPages, pageIndex + 1))}
            disabled={pageIndex >= totalPages}
            className="p-1.5 rounded bg-slate-950 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
