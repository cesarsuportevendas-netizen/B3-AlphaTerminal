import React from 'react';
import { Upload, Download, RefreshCw, BarChart3, Database } from 'lucide-react';
import { ActiveSection } from '../types/stock';

interface HeaderProps {
  activeSection: ActiveSection;
  onSelectSection: (section: ActiveSection) => void;
  onOpenUpload: () => void;
  onExportExcel: () => void;
  onExportCSV?: () => void;
  onResetToDefault: () => void;
  totalStocks: number;
  filteredStocks: number;
  sourceName: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeSection,
  onSelectSection,
  onOpenUpload,
  onExportExcel,
  onExportCSV,
  onResetToDefault,
  totalStocks,
  filteredStocks,
  sourceName,
}) => {
  const navItems: { id: ActiveSection; label: string }[] = [
    { id: 'overview', label: 'Visão Geral' },
    { id: 'valuation', label: 'Valuation & Preço Justo' },
    { id: 'profitability', label: 'Rentabilidade & Margens' },
    { id: 'debt', label: 'Endividamento & Solvência' },
    { id: 'growth', label: 'Crescimento & Dividendos' },
    { id: 'table', label: 'Tabela Completa' },
    { id: 'ai_news', label: 'Radar IA & Fatos Relevantes' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
                B3 Fundamental
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                {sourceName} · {filteredStocks} de {totalStocks} ativos
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectSection(item.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-slate-800 text-emerald-400 shadow-sm border border-slate-700/60 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Action controls */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onResetToDefault}
              title="Restaurar base padrão B3"
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 rounded-md transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Base Padrão</span>
            </button>

            <button
              onClick={onExportExcel}
              title="Exportar planilha Excel (.xlsx)"
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Excel (.xlsx)</span>
            </button>

            {onExportCSV && (
              <button
                onClick={onExportCSV}
                title="Exportar arquivo CSV (.csv)"
                className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>CSV</span>
              </button>
            )}

            <button
              onClick={onOpenUpload}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors shadow-sm shadow-emerald-950/20"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Carregar CSV / .xlsx</span>
            </button>
          </div>
        </div>

        {/* Mobile subnav */}
        <div className="lg:hidden flex items-center gap-2 overflow-x-auto py-2 border-t border-slate-800/60 scrollbar-none">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectSection(item.id)}
                className={`px-2.5 py-1 text-xs font-medium rounded whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-800 text-emerald-400 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
