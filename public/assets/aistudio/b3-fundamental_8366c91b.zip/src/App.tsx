import React, { useState, useMemo } from 'react';
import { DEFAULT_B3_DATA } from './data/defaultB3Data';
import { StockData, FilterState, ActiveSection } from './types/stock';
import { Header } from './components/Header';
import { SidebarFilters } from './components/SidebarFilters';
import { OverviewSection } from './components/OverviewSection';
import { ValuationSection } from './components/ValuationSection';
import { ProfitabilitySection } from './components/ProfitabilitySection';
import { DebtSection } from './components/DebtSection';
import { GrowthSection } from './components/GrowthSection';
import { StockTable } from './components/StockTable';
import { AINewsSection } from './components/AINewsSection';
import { CompanyModal } from './components/CompanyModal';
import { FileUploadModal } from './components/FileUploadModal';
import { exportToExcel, exportToCSV } from './utils/excelParser';
import { Filter, ChevronRight, Layers } from 'lucide-react';

const INITIAL_FILTERS: FilterState = {
  search: '',
  setor: 'ALL',
  minPreco: 0,
  maxPreco: 500,
  minLiq2meses: 0,
  minPatrimLiq: 0,
  onlyProfitable: false,
  onlyDividendPayers: false,
  maxDivLiqPatrim: null,
};

export default function App() {
  const [stocks, setStocks] = useState<StockData[]>(DEFAULT_B3_DATA);
  const [sourceName, setSourceName] = useState<string>('Base Padrão B3');
  const [activeSection, setActiveSection] = useState<ActiveSection>('overview');
  const [filters, setFilters] = useState<FilterState>(INITIAL_FILTERS);
  const [selectedStock, setSelectedStock] = useState<StockData | null>(null);
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);

  // Available unique sectors
  const availableSectors = useMemo(() => {
    const set = new Set<string>();
    for (const s of stocks) {
      if (s.setor) set.add(s.setor);
    }
    return Array.from(set).sort();
  }, [stocks]);

  // Filtered stocks computation
  const filteredStocks = useMemo(() => {
    return stocks.filter((s) => {
      // 1. Search (Ticker or Company Name)
      if (filters.search.trim()) {
        const query = filters.search.toLowerCase().trim();
        const matchesTicker = s.papel.toLowerCase().includes(query);
        const matchesName = s.nomeEmpresa ? s.nomeEmpresa.toLowerCase().includes(query) : false;
        const matchesSector = s.setor ? s.setor.toLowerCase().includes(query) : false;
        if (!matchesTicker && !matchesName && !matchesSector) {
          return false;
        }
      }

      // 2. Sector filter
      if (filters.setor !== 'ALL' && s.setor !== filters.setor) {
        return false;
      }

      // 3. Price range
      if (s.cotacao < filters.minPreco || s.cotacao > filters.maxPreco) {
        return false;
      }

      // 4. Minimum 2-month Liquidity
      if (s.liq2meses < filters.minLiq2meses) {
        return false;
      }

      // 5. Minimum Net Worth (Patrimônio Líquido)
      if (s.patrimLiq < filters.minPatrimLiq) {
        return false;
      }

      // 6. Only profitable (P/L > 0)
      if (filters.onlyProfitable && (s.pl === null || s.pl <= 0)) {
        return false;
      }

      // 7. Only dividend payers (DY > 0)
      if (filters.onlyDividendPayers && (s.divYield === null || s.divYield <= 0)) {
        return false;
      }

      // 8. Max Leverage (Dívida Líquida / Patrimônio <= maxDivLiqPatrim)
      if (filters.maxDivLiqPatrim !== null) {
        if (s.divLiqPatrim !== null && s.divLiqPatrim > filters.maxDivLiqPatrim) {
          return false;
        }
      }

      return true;
    });
  }, [stocks, filters]);

  const handleResetFilters = () => {
    setFilters(INITIAL_FILTERS);
  };

  const handleExportExcel = () => {
    exportToExcel(filteredStocks, 'empresas_b3_filtradas.xlsx');
  };

  const handleExportCSV = () => {
    exportToCSV(filteredStocks, 'empresas_b3_filtradas.csv');
  };

  const handleResetToDefault = () => {
    setStocks(DEFAULT_B3_DATA);
    setSourceName('Base Padrão B3');
    setFilters(INITIAL_FILTERS);
  };

  const handleDataLoaded = (newData: StockData[], newSourceName: string) => {
    setStocks(newData);
    setSourceName(newSourceName);
    setFilters(INITIAL_FILTERS);
  };

  const getSectionTitle = (sec: ActiveSection) => {
    switch (sec) {
      case 'overview':
        return {
          title: 'Visão Geral do Mercado',
          desc: 'Panorama executivo, múltiplos consolidados e indicadores agregados das empresas selecionadas.',
        };
      case 'valuation':
        return {
          title: 'Valuation & Preço Justo',
          desc: 'Análise de múltiplos P/L, P/VP, EV/EBITDA, modelo clássico de Graham e Preço Teto Bazin.',
        };
      case 'profitability':
        return {
          title: 'Rentabilidade & Eficiência Operacional',
          desc: 'Retornos sobre o capital (ROIC e ROE), margens de faturamento e moats econômicos.',
        };
      case 'debt':
        return {
          title: 'Endividamento & Estrutura de Capital',
          desc: 'Alavancagem financeira, solvência de curto prazo, matriz de risco e auditoria de balanço.',
        };
      case 'growth':
        return {
          title: 'Crescimento & Histórico de Proventos',
          desc: 'Crescimento de receita em 5 anos (CAGR), histórico de Dividend Yield e geração de caixa.',
        };
      case 'table':
        return {
          title: 'Tabela Completa de Indicadores',
          desc: 'Planilha financeira interativa com ordenação por colunas, paginação e exportação.',
        };
      case 'ai_news':
        return {
          title: 'Radar IA: Fatos Relevantes & Notícias da Bolsa',
          desc: 'Pesquisa em tempo real conectada à internet via Google Search para capturar fatos relevantes da CVM, notícias e acontecimentos macroeconômicos.',
        };
    }
  };

  const currentSectionMeta = getSectionTitle(activeSection);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased">
      {/* 1. Header Navigation Bar */}
      <Header
        activeSection={activeSection}
        onSelectSection={setActiveSection}
        onOpenUpload={() => setIsUploadOpen(true)}
        onExportExcel={handleExportExcel}
        onExportCSV={handleExportCSV}
        onResetToDefault={handleResetToDefault}
        totalStocks={stocks.length}
        filteredStocks={filteredStocks.length}
        sourceName={sourceName}
      />

      {/* 2. Main Workspace Layout: Sidebar + Viewport */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex">
        {/* Sidebar Filters */}
        <SidebarFilters
          filters={filters}
          onChangeFilters={setFilters}
          onResetFilters={handleResetFilters}
          availableSectors={availableSectors}
          totalCount={stocks.length}
          filteredCount={filteredStocks.length}
          isOpenMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
        />

        {/* Central Viewport Content */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 space-y-6">
          {/* Section Breadcrumb & Title */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                <span>B3 Fundamental</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                <span className="text-emerald-400 font-medium capitalize">
                  {activeSection === 'overview' ? 'Visão Geral' : currentSectionMeta.title}
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                {currentSectionMeta.title}
              </h1>
              <p className="text-xs text-slate-400 mt-1 max-w-3xl leading-relaxed">
                {currentSectionMeta.desc}
              </p>
            </div>

            {/* Mobile Filter Toggle Button */}
            <button
              onClick={() => setIsMobileSidebarOpen(true)}
              className="lg:hidden inline-flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-md text-xs font-semibold text-white self-start"
            >
              <Filter className="w-3.5 h-3.5 text-emerald-400" />
              <span>Filtros ({filteredStocks.length}/{stocks.length})</span>
            </button>
          </div>

          {/* Active Section Content View */}
          {activeSection === 'overview' && (
            <OverviewSection
              stocks={filteredStocks}
              onSelectSection={setActiveSection}
              onSelectStock={setSelectedStock}
            />
          )}

          {activeSection === 'valuation' && (
            <ValuationSection
              stocks={filteredStocks}
              onSelectStock={setSelectedStock}
            />
          )}

          {activeSection === 'profitability' && (
            <ProfitabilitySection
              stocks={filteredStocks}
              onSelectStock={setSelectedStock}
            />
          )}

          {activeSection === 'debt' && (
            <DebtSection
              stocks={filteredStocks}
              onSelectStock={setSelectedStock}
            />
          )}

          {activeSection === 'growth' && (
            <GrowthSection
              stocks={filteredStocks}
              onSelectStock={setSelectedStock}
            />
          )}

          {activeSection === 'table' && (
            <StockTable
              stocks={filteredStocks}
              onSelectStock={setSelectedStock}
            />
          )}

          {activeSection === 'ai_news' && (
            <AINewsSection
              stocks={filteredStocks}
              onSelectStock={setSelectedStock}
            />
          )}
        </main>
      </div>

      {/* 3. Company Deep Dive Modal */}
      <CompanyModal
        stock={selectedStock}
        onClose={() => setSelectedStock(null)}
      />

      {/* 4. Excel / CSV File Upload Modal */}
      <FileUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onDataLoaded={handleDataLoaded}
        onResetToDefault={handleResetToDefault}
      />
    </div>
  );
}
