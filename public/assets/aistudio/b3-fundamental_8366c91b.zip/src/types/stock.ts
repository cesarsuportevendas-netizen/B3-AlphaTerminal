export interface StockData {
  id: string;
  papel: string;
  cotacao: number;
  pl: number | null;
  pvp: number | null;
  psr: number | null;
  divYield: number | null; // in %
  pAtivo: number | null;
  pCapGiro: number | null;
  pEbit: number | null;
  pAtivCircLiq: number | null;
  evEbitda: number | null;
  evEbit: number | null;
  mrgEbit: number | null; // in %
  mrgLiq: number | null; // in %
  mrgBruta: number | null; // in %
  liqCorr: number | null;
  roic: number | null; // in %
  roe: number | null; // in %
  liq2meses: number; // in R$
  patrimLiq: number; // in R$
  divBrutaPatrim: number | null;
  divLiqPatrim: number | null;
  crescRec5a: number | null; // in %
  setor: string;
  subsetor?: string;
  nomeEmpresa?: string;
  lpa?: number | null;
  vpa?: number | null;
}

export interface FilterState {
  search: string;
  setor: string;
  minPreco: number;
  maxPreco: number;
  minLiq2meses: number;
  minPatrimLiq: number;
  onlyProfitable: boolean;
  onlyDividendPayers: boolean;
  maxDivLiqPatrim: number | null;
}

export type ActiveSection = 'overview' | 'valuation' | 'profitability' | 'debt' | 'growth' | 'table' | 'ai_news';

export interface AIAnalysisResult {
  ticker: string;
  companyName: string;
  analysis: string;
  sources: { title: string; url: string }[];
  timestamp: string;
}

export interface SectorSummary {
  setor: string;
  totalEmpresas: number;
  mediaPL: number;
  mediaPVP: number;
  mediaROE: number;
  mediaROIC: number;
  mediaDY: number;
}
