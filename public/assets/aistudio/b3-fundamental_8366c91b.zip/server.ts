import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Google GenAI client server-side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Endpoint for AI fundamental analysis grounded with Google Search
app.post('/api/ai/analyze-stock', async (req, res) => {
  try {
    const {
      ticker,
      companyName,
      sector,
      cotacao,
      pl,
      pvp,
      roic,
      roe,
      divLiqPatrim,
      divYield,
    } = req.body;

    if (!ticker) {
      return res.status(400).json({ error: 'Ticker da ação é obrigatório.' });
    }

    const prompt = `Você é um Arquiteto de Software e Analista Sênior de Equity Research especializado na Bolsa de Valores Brasileira (B3).
Pesquise na internet sobre os fatos relevantes, notícias recentes e acontecimentos de mercado envolvendo a empresa:
- Papel (Ticker): ${ticker}
- Nome da Empresa: ${companyName || ticker}
- Setor: ${sector || 'B3'}
- Cotação Atual: R$ ${cotacao || 'N/A'}
- Múltiplos: P/L=${pl || 'N/A'}x, P/VP=${pvp || 'N/A'}x, ROIC=${roic || 'N/A'}%, ROE=${roe || 'N/A'}%, Dívida Líq/PL=${divLiqPatrim || 'N/A'}x, Dividend Yield=${divYield || 'N/A'}%

Pesquise especificamente:
1. Fatos Relevantes e Comunicados ao Mercado recentes (CVM, M&A, resultados trimestrais, dividendos/JCP aprovados, mudanças no conselho/gestão, emissões ou reestruturações).
2. Notícias recentes que impactam a cotação e o sentimento de mercado para este ativo.
3. Riscos macroeconômicos, setoriais e regulatórios atuais (taxa Selic, câmbio, commodities, tributação).
4. Veredito Fundamentalista: Conecte os acontecimentos recentes com os múltiplos quantitativos da empresa (valuation e solidez financeira).

Estruture sua resposta de forma executiva e profissional em português com os seguintes tópicos em Markdown:
### 📌 Fatos Relevantes & Acontecimentos Recentes
(Destaque os fatos mais relevantes com datas ou períodos aproximados)

### 📰 Notícias de Mercado & Impacto na Cotação
(Principais catalisadores positivos e negativos noticiados recentemente)

### ⚖️ Cruzamento Qualitativo x Múltiplos Fundamentalistas
(Como os fatos recentes explicam ou justificam os múltiplos atuais como P/L, ROIC e endividamento)

### 💡 Perspectiva & Riscos para o Investidor
(Resumo dos principais pontos de atenção e gatilhos de valor no curto/médio prazo)

Seja objetivo, factual e imparcial.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const analysisText = response.text || 'Não foi possível gerar a análise para este ativo.';
    
    // Extract web search grounding citations
    const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const sources: { title: string; url: string }[] = [];

    if (rawChunks && Array.isArray(rawChunks)) {
      for (const chunk of rawChunks) {
        if (chunk.web?.uri && chunk.web?.title) {
          sources.push({
            title: chunk.web.title,
            url: chunk.web.uri,
          });
        }
      }
    }

    return res.json({
      ticker,
      companyName: companyName || ticker,
      analysis: analysisText,
      sources,
      timestamp: new Date().toISOString(),
    });
  } catch (err: unknown) {
    console.error('Error in /api/ai/analyze-stock:', err);
    const message = err instanceof Error ? err.message : 'Erro interno ao consultar inteligência artificial.';
    return res.status(500).json({ error: message });
  }
});

// Configure Vite middleware in development or serve static in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT} (isDev: ${isDev})`);
  });
}

startServer();
